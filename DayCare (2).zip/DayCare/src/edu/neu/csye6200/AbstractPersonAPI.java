package edu.neu.csye6200;

public abstract class AbstractPersonAPI {
	/**
	 * API
	 */
	public abstract void show();
}

