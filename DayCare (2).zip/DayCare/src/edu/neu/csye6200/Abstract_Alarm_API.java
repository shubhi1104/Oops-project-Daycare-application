package edu.neu.csye6200;

public abstract class Abstract_Alarm_API {
	
public abstract void vaccination();
public abstract void register();
public abstract void show();
}
