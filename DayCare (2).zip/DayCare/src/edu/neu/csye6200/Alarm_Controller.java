package edu.neu.csye6200;

import java.time.LocalDate;
import java.time.Month;

import edu.neu.csye6200.SimpleFactory.SimpleCriteria;

public class Alarm_Controller {
	
	LocalDate date1 = LocalDate.of(2017, Month.MARCH, 31);
	LocalDate date2 = LocalDate.of(2018, Month.JULY, 20);
	LocalDate date3 = LocalDate.of(2018, Month.JANUARY, 20);
	LocalDate date4 = LocalDate.of(2018, Month.FEBRUARY, 26);
	LocalDate date5 = LocalDate.of(2017, Month.OCTOBER, 20);
	LocalDate date6 = LocalDate.of(2017, Month.JULY, 20);
	
	LocalDate date7 = LocalDate.of(2017, Month.APRIL, 20);
	LocalDate date8 = LocalDate.of(2017, Month.JULY, 02);
	LocalDate date9 = LocalDate.of(2017, Month.JANUARY, 13);
	LocalDate date10 = LocalDate.of(2017, Month.FEBRUARY, 26);
	LocalDate date11 = LocalDate.of(2017, Month.AUGUST, 31);
	

public void vaccine() {
	Alarm_Clock obj1 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date1, "Jimmy");
	Alarm_Clock obj2 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date2, "Sally");
	Alarm_Clock obj3 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Lizzy");
	Alarm_Clock obj4 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Markie");
	Alarm_Clock obj5 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Johnny");
	
	Alarm_Clock obj6 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Bobby");
	Alarm_Clock obj7 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date2, "Billy");
	Alarm_Clock obj8 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Evie");
	Alarm_Clock obj9 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date1, "Becky");
	Alarm_Clock obj10 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Jessie");
	Alarm_Clock obj11 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Jackie");
	Alarm_Clock obj12 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Laurie");
	Alarm_Clock obj13 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Cathey");
	Alarm_Clock obj14 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Millie");
	Alarm_Clock obj15 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Ruthie");
	
	Alarm_Clock obj16 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Stanley");
	Alarm_Clock obj17 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Mary");
	Alarm_Clock obj18 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date1, "Annie");
	Alarm_Clock obj19 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Melisa");
	Alarm_Clock obj20 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Mia");
	Alarm_Clock obj21 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Lorren");
	Alarm_Clock obj22 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Michael");
	Alarm_Clock obj23 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Tony");
	Alarm_Clock obj24 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Lia");
	Alarm_Clock obj25 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Jay");
	Alarm_Clock obj26 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Steve");

	Alarm_Clock obj27 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date1, "Nishu");
	Alarm_Clock obj28 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date2, "Linda");
	Alarm_Clock obj29 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Pinky");
	Alarm_Clock obj30 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Lemon");
	Alarm_Clock obj31 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Tesla");
	Alarm_Clock obj32 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Guru");
	Alarm_Clock obj33 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Niti");
	Alarm_Clock obj34 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Cindy");
	Alarm_Clock obj35 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Kuli");
	Alarm_Clock obj36 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Medan");
	Alarm_Clock obj37 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Posy");
	
	Alarm_Clock obj38 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date1, "Mike");
	Alarm_Clock obj39 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date2, "Post");
	Alarm_Clock obj40 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Malone");
	Alarm_Clock obj41 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Pill");
	Alarm_Clock obj42 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Nill");
	Alarm_Clock obj43 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Vox");
	Alarm_Clock obj44 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Cox");
	Alarm_Clock obj45 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Deck");
	Alarm_Clock obj46 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date3, "Peck");
	Alarm_Clock obj47 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date4, "Medan");
	Alarm_Clock obj48 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Meck");
	Alarm_Clock obj49 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date5, "Like");
	Alarm_Clock obj50 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.VACCINE, date6, "Nike");
	
	
	obj1.show();
	obj2.show();
	obj3.show();
	obj4.show();
	obj5.show();
	obj6.show();
	obj7.show();
	obj8.show();
	obj9.show();
	obj10.show();
	obj11.show();
	obj12.show();
	obj13.show();
	obj14.show();
	obj15.show();
	obj16.show();
	obj17.show();
	obj18.show();
	obj19.show();
	obj20.show();
	obj21.show();
	obj22.show();
	obj23.show();
	obj24.show();
	obj25.show();
	obj26.show();
	obj27.show();
	obj28.show();
	obj29.show();
	obj30.show();
	obj31.show();
	obj32.show();
	obj33.show();
	obj34.show();
	obj35.show();
	obj36.show();
	obj37.show();
	obj38.show();
	obj39.show();
	obj40.show();
	obj41.show();
	obj42.show();
	obj43.show();
	obj44.show();
	obj45.show();
	obj46.show();
	obj47.show();
	obj48.show();
	obj49.show();
	obj50.show();
	
}

public void registration() {
	
	Alarm_Clock obj1 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Jimmy");
	Alarm_Clock obj2 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Sally");
	Alarm_Clock obj3 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Lizzy");
	Alarm_Clock obj4 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Markie");
	Alarm_Clock obj5 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Johnny");
	Alarm_Clock obj6 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Bobby");
	Alarm_Clock obj7 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Billy");
	Alarm_Clock obj8 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Evie");
	Alarm_Clock obj9 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Becky");
	Alarm_Clock obj10 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Jessie");
	Alarm_Clock obj11 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Jackie");
	Alarm_Clock obj12 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Cathey");
	Alarm_Clock obj14 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Millie");
	Alarm_Clock obj15 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Ruthie");
	Alarm_Clock obj13 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Cathey");
	Alarm_Clock obj16 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Stanley");
	Alarm_Clock obj17 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Mary");
	Alarm_Clock obj18 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Annie");
	Alarm_Clock obj19 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Melisa");
	Alarm_Clock obj20 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Mia");
	Alarm_Clock obj21 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Lorren");
	Alarm_Clock obj22 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Michael");
	Alarm_Clock obj23 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Tony");
	Alarm_Clock obj24 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Lia");
	Alarm_Clock obj25 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Jay");
	Alarm_Clock obj26 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Steve");

	Alarm_Clock obj27 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Nishu");
	Alarm_Clock obj28 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Linda");
	Alarm_Clock obj29 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Pinky");
	Alarm_Clock obj30 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Lemon");
	Alarm_Clock obj31 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Tesla");
	Alarm_Clock obj32 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Guru");
	Alarm_Clock obj33 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Niti");
	Alarm_Clock obj34 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Cindy");
	Alarm_Clock obj35 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Kuli");
	Alarm_Clock obj36 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date9, "Medan");
	Alarm_Clock obj37 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Posy");
	
	Alarm_Clock obj38 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Mike");
	Alarm_Clock obj39 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Post");
	Alarm_Clock obj40 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Malone");
	Alarm_Clock obj41 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Pill");
	Alarm_Clock obj42 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Nill");
	Alarm_Clock obj43 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Vox");
	Alarm_Clock obj44 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Cox");
	Alarm_Clock obj45 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Deck");
	Alarm_Clock obj46 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Peck");
	Alarm_Clock obj47 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date10, "Medan");
	Alarm_Clock obj48 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date8, "Meck");
	Alarm_Clock obj49 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date7, "Like");
	Alarm_Clock obj50 = SimpleFactory.getbjectAlarmClock(SimpleCriteria.REGISTRATION, date11, "Nike");
	
	/*Registration obj1 = new Registration(date1, "Abhnav Jain");
	Registration obj2 = new Registration(date2, "Shubhi Sharma");
	Registration obj3 = new Registration(date3, "Prasad Kanade");
	Registration obj4 = new Registration(date4, "Suraj Ghule");
	Registration obj5 = new Registration(date5, "Yatin Kewale");*/
	
	obj1.show();
	obj2.show();
	obj3.show();
	obj4.show();
	obj5.show();
	obj6.show();
	obj7.show();
	obj8.show();
	obj9.show();
	obj10.show();
	obj11.show();
	obj12.show();
	obj13.show();
	obj14.show();
	obj15.show();
	obj16.show();
	obj17.show();
	obj18.show();
	obj19.show();
	obj20.show();
	obj21.show();
	obj22.show();
	obj23.show();
	obj24.show();
	obj25.show();
	obj26.show();
	
	obj27.show();
	obj28.show();
	obj29.show();
	obj30.show();
	obj31.show();
	obj32.show();
	
	obj33.show();
	obj34.show();
	obj35.show();
	obj36.show();
	obj37.show();
	obj38.show();
	
	obj39.show();
	obj40.show();
	obj41.show();
	obj42.show();
	obj43.show();
	obj44.show();
	
	obj45.show();
	obj46.show();
	obj47.show();
	obj48.show();
	obj49.show();
	obj50.show();
}

	public void demo1() {
		System.out.println("################ Welcome to NEU Daycare ################ \n");
		System.out.println("*****************Vaccination Alarm******************* \n");
		vaccine();
		System.out.println("\n");
		
	
        }
        public void demo2() {
		System.out.println("*****************Registration Alarm******************* \n");
		registration();
		System.out.println("\n");
	
}
}
