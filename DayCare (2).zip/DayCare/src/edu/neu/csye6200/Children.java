package edu.neu.csye6200;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class Children extends Person {

	private String name;
	private Date dateOfBirth;
	private String group;
	private Long age;
	
	Teacher teacher = new Teacher();
	Room room = new Room();
	
	//ArrayList<Person> teacherList = new ArrayList<Person>();
	
	public Children() throws ParseException {
		//super();
		this.name = "Nikunj";
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");	      
	    Date birthDate1 = sdf1.parse("12-09-2017"); 
		this.dateOfBirth = birthDate1;
		this.group = "group1";
		
	}
	
	
	public Children(String name, Date dateOfBirth, List<Children> childrens) {
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.group = this.assignGroup(this.dateOfBirth);
		childrens.add(this);
		//teacher.addChildren(this);
		this.assignTeacher(this.group, childrens);
		
		teacher.setGroupName(this.group);
		room = this.assignRoom(teacher);
		
		System.out.println(this.group + " is Assigned to : " + this.name + ", Date of Birth is : " + this.dateOfBirth);
		System.out.println(this.group + " is Assigned to : " + teacher.getTeacherName());
		System.out.println("Room assigned to : " + teacher.getTeacherName() + " & " + teacher.getGroupName() + " is : " + room.getRoomNumber());
		System.out.println("\n");
		
		if(childrens.size() == 50) {
			System.out.println("********** Sorted List Of Childrens on Age Starts***********");
			Collections.sort(childrens, (p1, p2) -> p1.age.intValue() - p2.age.intValue());
			for (Children element : childrens) {
				System.out.println("Age is : " + element.age + " , " + element);
			    //System.out.println(element);
			}
			System.out.println("********** Sorted List Of Childrens on Age Ends***********");
                        //MyDayCareGUI myGui1 = new MyDayCareGUI();
                        //MyDayCareGUI myGui = new MyDayCareGUI(childrens);
                        
		}
	}
	
	public Room assignRoom(Teacher teacher) {
		
		if(teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 1")) {
			room.setRoomNumber("A-301");
		}else if(teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 2")) {
			room.setRoomNumber("A-302");
		}else if(teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 3")) {
			room.setRoomNumber("A-303");
		}else if(teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 4")) {
			room.setRoomNumber("A-304");
		}else if (teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 5")) {
			room.setRoomNumber("A-305");
		}else if (teacher.getGroupName().equalsIgnoreCase(this.group) && teacher.getTeacherName().equalsIgnoreCase("Teacher 6")) {
			room.setRoomNumber("A-306");
		}else {
			room.setRoomNumber("A-307");
		}
		
		return room;
	}

	private Teacher assignTeacher(String groupName, List<Children> childrens) {
		
		if(groupName == "Group 1") {
			teacher.setTeacherName("Teacher 1");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
			
			
		}else if(groupName == "Group 2") {
			teacher.setTeacherName("Teacher 2");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
	
			
		}else if(groupName == "Group 3") {
			teacher.setTeacherName("Teacher 3");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
			
		}else if(groupName == "Group 4") {
			teacher.setTeacherName("Teacher 4");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
			
		}else if(groupName == "Group 5") {
			teacher.setTeacherName("Teacher 5");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
			
		}else if(groupName == "Group 6") {
			teacher.setTeacherName("Teacher 6");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
			
		}else {
			teacher.setTeacherName("Teacher 7");
			teacher.setGroupName(groupName);
			//System.out.println("List count" + childrens.size());
			//teacherList.add(this);
			//System.out.println("Assigned to -->"  + teacher.getTeacherName() + teacherList);
		}
		return teacher;
		
	}

	public String assignGroup(Date date) {
		String groupName = "";
		
		LocalDate localDate = date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		Integer month = localDate.getMonthValue();
		Integer year = localDate.getYear();
		Integer day = localDate.getDayOfMonth();
		LocalDate pastDate = LocalDate.of(year, month, day);
		LocalDate now = LocalDate.now();
		
		Long intervalMonths = ChronoUnit.MONTHS.between(pastDate, now);
			
		Long age = intervalMonths;
		//Logic to assign groups to children
		if(age >= 6 && age <= 12) {
			groupName = "Group 1";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else if(age >= 13 && age <= 24) {
			groupName = "Group 2";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else if(age >= 25 && age <= 35) {
			groupName = "Group 3";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else if(age >= 36 && age <= 47) {
			groupName = "Group 4";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else if(age >= 48 && age <= 59) {
			groupName = "Group 5";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else if(age >=60){
			groupName = "Group 6";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}else {
			groupName =  "Other Group";
			this.age = age;
			System.out.println("Age of " + this.name + " is " + this.age + " months");
		}
		
		return groupName;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
	@Override
	public void show() {
		System.out.println(this.toString());
		System.out.println("\n");
	}

	@Override
	public String toString() {
		return "Name of the children is : " + name + ", Date of Birth is : " + dateOfBirth + ","
				+ " Group assigned is : " + group;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}


	public Long getAge() {
		return age;
	}


	public void setAge(Long age) {
		this.age = age;
	}
	
	

}
