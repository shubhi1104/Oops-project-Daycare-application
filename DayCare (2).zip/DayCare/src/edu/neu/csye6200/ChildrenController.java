package edu.neu.csye6200;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.List;

import edu.neu.csye6200.SimpleFactory.SimpleCriteria;

public class ChildrenController {
		
		public ChildrenController() {
						
		}
		

		public static void demo() throws ParseException {
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");	      
		     
			
			Person c1 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Jimmy", sdf.parse("12-09-2017"));
			//Person c51 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Nikunj", sdf.parse("12-09-2017"));
			Person c2 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Sally", sdf.parse("12-02-2017"));
			Person c3 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Lizzy", sdf.parse("17-02-2013"));
			Person c4 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Markie", sdf.parse("17-08-2015"));
			Person c5 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Johnny", sdf.parse("17-04-2017"));
			Person c6 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Bobby", sdf.parse("17-04-2014"));
			Person c7 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Billy", sdf.parse("17-02-2016"));
			Person c8 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Evie", sdf.parse("17-12-2014"));
			Person c9 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Becky", sdf.parse("17-11-2015"));
			Person c10 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Jessie", sdf.parse("17-02-2017"));
			Person c11 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Jackie", sdf.parse("17-04-2017"));
			Person c12 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Laurie", sdf.parse("17-02-2016"));
			Person c13 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Cathey", sdf.parse("17-04-2017"));
			Person c14 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Millie", sdf.parse("17-01-2013"));
			Person c15 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Ruthie", sdf.parse("17-06-2015"));
			Person c16 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Stanley", sdf.parse("17-11-2013"));
			Person c17 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Mary", sdf.parse("17-11-2014"));
			Person c18 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Annie", sdf.parse("17-10-2015"));
			Person c19 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Melisa", sdf.parse("17-02-2017"));
			Person c20 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Mia", sdf.parse("16-02-2017"));
			Person c21 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Lorren", sdf.parse("14-02-2017"));
			Person c22 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Michael", sdf.parse("17-12-2014"));
			Person c23 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Tony", sdf.parse("14-12-2014"));
			Person c24 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Lia", sdf.parse("15-12-2014"));
			Person c25 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Jay", sdf.parse("16-12-2014"));
			Person c26 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Steve", sdf.parse("18-12-2014"));
			Person c27 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Nishu", sdf.parse("19-12-2014"));
			Person c28 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Linda", sdf.parse("17-04-2014"));
			Person c29 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Pinky", sdf.parse("17-04-2014"));
			Person c30 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Lemon", sdf.parse("17-04-2014"));
			Person c31 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Tesla", sdf.parse("16-04-2014"));
			Person c32 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Guru", sdf.parse("10-04-2014"));
			Person c33 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Niti", sdf.parse("11-04-2014"));
			Person c34 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Cindy", sdf.parse("12-04-2014"));
			Person c35 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Kuli", sdf.parse("13-04-2014"));
			Person c36 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Medan", sdf.parse("14-04-2014"));
			Person c37 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Posy", sdf.parse("15-04-2014"));
			
			Person c38 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Mike", sdf.parse("17-02-2013"));
			Person c39 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Post", sdf.parse("17-02-2013"));
			Person c40 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Malone", sdf.parse("17-02-2013"));
			Person c41 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Pill", sdf.parse("17-02-2013"));
			Person c42 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Nill", sdf.parse("17-02-2013"));
			Person c43 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Vox", sdf.parse("17-02-2013"));
			Person c44 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Cox", sdf.parse("17-02-2013"));
			Person c45 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Deck", sdf.parse("17-02-2013"));
			Person c46 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Peck", sdf.parse("17-02-2013"));
			Person c47 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Meck", sdf.parse("17-02-2013"));
			Person c48 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Like", sdf.parse("17-02-2013"));
			Person c49 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Mole", sdf.parse("17-02-2013"));
			Person c50 = SimpleFactory.getObject(SimpleCriteria.CHILDREN, "Nike", sdf.parse("17-02-2013"));
		
			List<Person> newPerson = new ArrayList<Person>();
			newPerson.add(c1);
			newPerson.add(c2);
			newPerson.add(c3);
			newPerson.add(c4);
			newPerson.add(c5);
			newPerson.add(c6);
			newPerson.add(c7);
			newPerson.add(c8);
			newPerson.add(c9);
			newPerson.add(c10);
			newPerson.add(c11);
			newPerson.add(c12);
			newPerson.add(c13);
			newPerson.add(c14);
			newPerson.add(c15);
			newPerson.add(c16);
			newPerson.add(c17);
			newPerson.add(c18);
			newPerson.add(c19);
			newPerson.add(c20);
			newPerson.add(c21);
			newPerson.add(c22);
			newPerson.add(c23);
			newPerson.add(c24);
			newPerson.add(c25);
			newPerson.add(c26);
			newPerson.add(c27);
			newPerson.add(c28);
			newPerson.add(c29);
			newPerson.add(c30);
			newPerson.add(c31);
			newPerson.add(c32);
			newPerson.add(c33);
			newPerson.add(c34);
			newPerson.add(c35);
			newPerson.add(c36);
			newPerson.add(c37);
			newPerson.add(c38);
			newPerson.add(c39);
			newPerson.add(c40);
			newPerson.add(c41);
			newPerson.add(c42);
			newPerson.add(c43);
			newPerson.add(c44);
			newPerson.add(c45);
			newPerson.add(c46);
			newPerson.add(c47);
			newPerson.add(c48);
			newPerson.add(c49);
			newPerson.add(c50);
			
			/*for (Person person : newPerson) {
				person.show();
			}
			*/
		}
	}



