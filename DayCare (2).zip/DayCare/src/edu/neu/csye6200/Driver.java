package edu.neu.csye6200;

import java.text.ParseException;

public class Driver {

	public static void main(String[] args) throws ParseException {
		// Call the demo method of the controller class to create the object of the class Children
		/*
                Output :
Age of Jimmy is 7 months
Group 1 is Assigned to : Jimmy, Date of Birth is : Tue Sep 12 00:00:00 IST 2017
Group 1 is Assigned to : Teacher 1
Room assigned to : Teacher 1 & Group 1 is : A-301


Age of Sally is 14 months
Group 2 is Assigned to : Sally, Date of Birth is : Sun Feb 12 00:00:00 IST 2017
Group 2 is Assigned to : Teacher 2
Room assigned to : Teacher 2 & Group 2 is : A-302


Age of Lizzy is 62 months
Group 6 is Assigned to : Lizzy, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Markie is 32 months
Group 3 is Assigned to : Markie, Date of Birth is : Mon Aug 17 00:00:00 IST 2015
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Johnny is 12 months
Group 1 is Assigned to : Johnny, Date of Birth is : Mon Apr 17 00:00:00 IST 2017
Group 1 is Assigned to : Teacher 1
Room assigned to : Teacher 1 & Group 1 is : A-301


Age of Bobby is 48 months
Group 5 is Assigned to : Bobby, Date of Birth is : Thu Apr 17 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Billy is 26 months
Group 3 is Assigned to : Billy, Date of Birth is : Wed Feb 17 00:00:00 IST 2016
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Evie is 40 months
Group 4 is Assigned to : Evie, Date of Birth is : Wed Dec 17 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Becky is 29 months
Group 3 is Assigned to : Becky, Date of Birth is : Tue Nov 17 00:00:00 IST 2015
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Jessie is 14 months
Group 2 is Assigned to : Jessie, Date of Birth is : Fri Feb 17 00:00:00 IST 2017
Group 2 is Assigned to : Teacher 2
Room assigned to : Teacher 2 & Group 2 is : A-302


Age of Jackie is 12 months
Group 1 is Assigned to : Jackie, Date of Birth is : Mon Apr 17 00:00:00 IST 2017
Group 1 is Assigned to : Teacher 1
Room assigned to : Teacher 1 & Group 1 is : A-301


Age of Laurie is 26 months
Group 3 is Assigned to : Laurie, Date of Birth is : Wed Feb 17 00:00:00 IST 2016
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Cathey is 12 months
Group 1 is Assigned to : Cathey, Date of Birth is : Mon Apr 17 00:00:00 IST 2017
Group 1 is Assigned to : Teacher 1
Room assigned to : Teacher 1 & Group 1 is : A-301


Age of Millie is 63 months
Group 6 is Assigned to : Millie, Date of Birth is : Thu Jan 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Ruthie is 34 months
Group 3 is Assigned to : Ruthie, Date of Birth is : Wed Jun 17 00:00:00 IST 2015
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Stanley is 53 months
Group 5 is Assigned to : Stanley, Date of Birth is : Sun Nov 17 00:00:00 IST 2013
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Mary is 41 months
Group 4 is Assigned to : Mary, Date of Birth is : Mon Nov 17 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Annie is 30 months
Group 3 is Assigned to : Annie, Date of Birth is : Sat Oct 17 00:00:00 IST 2015
Group 3 is Assigned to : Teacher 3
Room assigned to : Teacher 3 & Group 3 is : A-303


Age of Melisa is 14 months
Group 2 is Assigned to : Melisa, Date of Birth is : Fri Feb 17 00:00:00 IST 2017
Group 2 is Assigned to : Teacher 2
Room assigned to : Teacher 2 & Group 2 is : A-302


Age of Mia is 14 months
Group 2 is Assigned to : Mia, Date of Birth is : Thu Feb 16 00:00:00 IST 2017
Group 2 is Assigned to : Teacher 2
Room assigned to : Teacher 2 & Group 2 is : A-302


Age of Lorren is 14 months
Group 2 is Assigned to : Lorren, Date of Birth is : Tue Feb 14 00:00:00 IST 2017
Group 2 is Assigned to : Teacher 2
Room assigned to : Teacher 2 & Group 2 is : A-302


Age of Michael is 40 months
Group 4 is Assigned to : Michael, Date of Birth is : Wed Dec 17 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Tony is 40 months
Group 4 is Assigned to : Tony, Date of Birth is : Sun Dec 14 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Lia is 40 months
Group 4 is Assigned to : Lia, Date of Birth is : Mon Dec 15 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Jay is 40 months
Group 4 is Assigned to : Jay, Date of Birth is : Tue Dec 16 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Steve is 40 months
Group 4 is Assigned to : Steve, Date of Birth is : Thu Dec 18 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Nishu is 40 months
Group 4 is Assigned to : Nishu, Date of Birth is : Fri Dec 19 00:00:00 IST 2014
Group 4 is Assigned to : Teacher 4
Room assigned to : Teacher 4 & Group 4 is : A-304


Age of Linda is 48 months
Group 5 is Assigned to : Linda, Date of Birth is : Thu Apr 17 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Pinky is 48 months
Group 5 is Assigned to : Pinky, Date of Birth is : Thu Apr 17 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Lemon is 48 months
Group 5 is Assigned to : Lemon, Date of Birth is : Thu Apr 17 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Tesla is 48 months
Group 5 is Assigned to : Tesla, Date of Birth is : Wed Apr 16 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Guru is 48 months
Group 5 is Assigned to : Guru, Date of Birth is : Thu Apr 10 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Niti is 48 months
Group 5 is Assigned to : Niti, Date of Birth is : Fri Apr 11 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Cindy is 48 months
Group 5 is Assigned to : Cindy, Date of Birth is : Sat Apr 12 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Kuli is 48 months
Group 5 is Assigned to : Kuli, Date of Birth is : Sun Apr 13 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Medan is 48 months
Group 5 is Assigned to : Medan, Date of Birth is : Mon Apr 14 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Posy is 48 months
Group 5 is Assigned to : Posy, Date of Birth is : Tue Apr 15 00:00:00 IST 2014
Group 5 is Assigned to : Teacher 5
Room assigned to : Teacher 5 & Group 5 is : A-305


Age of Mike is 62 months
Group 6 is Assigned to : Mike, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Post is 62 months
Group 6 is Assigned to : Post, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Malone is 62 months
Group 6 is Assigned to : Malone, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Pill is 62 months
Group 6 is Assigned to : Pill, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Nill is 62 months
Group 6 is Assigned to : Nill, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Vox is 62 months
Group 6 is Assigned to : Vox, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Cox is 62 months
Group 6 is Assigned to : Cox, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Deck is 62 months
Group 6 is Assigned to : Deck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Peck is 62 months
Group 6 is Assigned to : Peck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Meck is 62 months
Group 6 is Assigned to : Meck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Like is 62 months
Group 6 is Assigned to : Like, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Mole is 62 months
Group 6 is Assigned to : Mole, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


Age of Nike is 62 months
Group 6 is Assigned to : Nike, Date of Birth is : Sun Feb 17 00:00:00 IST 2013
Group 6 is Assigned to : Teacher 6
Room assigned to : Teacher 6 & Group 6 is : A-306


********** Sorted List Of Childrens on Age Starts***********
Age is : 7 , Name of the children is : Jimmy, Date of Birth is : Tue Sep 12 00:00:00 IST 2017, Group assigned is : Group 1
Age is : 12 , Name of the children is : Johnny, Date of Birth is : Mon Apr 17 00:00:00 IST 2017, Group assigned is : Group 1
Age is : 12 , Name of the children is : Jackie, Date of Birth is : Mon Apr 17 00:00:00 IST 2017, Group assigned is : Group 1
Age is : 12 , Name of the children is : Cathey, Date of Birth is : Mon Apr 17 00:00:00 IST 2017, Group assigned is : Group 1
Age is : 14 , Name of the children is : Sally, Date of Birth is : Sun Feb 12 00:00:00 IST 2017, Group assigned is : Group 2
Age is : 14 , Name of the children is : Jessie, Date of Birth is : Fri Feb 17 00:00:00 IST 2017, Group assigned is : Group 2
Age is : 14 , Name of the children is : Melisa, Date of Birth is : Fri Feb 17 00:00:00 IST 2017, Group assigned is : Group 2
Age is : 14 , Name of the children is : Mia, Date of Birth is : Thu Feb 16 00:00:00 IST 2017, Group assigned is : Group 2
Age is : 14 , Name of the children is : Lorren, Date of Birth is : Tue Feb 14 00:00:00 IST 2017, Group assigned is : Group 2
Age is : 26 , Name of the children is : Billy, Date of Birth is : Wed Feb 17 00:00:00 IST 2016, Group assigned is : Group 3
Age is : 26 , Name of the children is : Laurie, Date of Birth is : Wed Feb 17 00:00:00 IST 2016, Group assigned is : Group 3
Age is : 29 , Name of the children is : Becky, Date of Birth is : Tue Nov 17 00:00:00 IST 2015, Group assigned is : Group 3
Age is : 30 , Name of the children is : Annie, Date of Birth is : Sat Oct 17 00:00:00 IST 2015, Group assigned is : Group 3
Age is : 32 , Name of the children is : Markie, Date of Birth is : Mon Aug 17 00:00:00 IST 2015, Group assigned is : Group 3
Age is : 34 , Name of the children is : Ruthie, Date of Birth is : Wed Jun 17 00:00:00 IST 2015, Group assigned is : Group 3
Age is : 40 , Name of the children is : Evie, Date of Birth is : Wed Dec 17 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Michael, Date of Birth is : Wed Dec 17 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Tony, Date of Birth is : Sun Dec 14 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Lia, Date of Birth is : Mon Dec 15 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Jay, Date of Birth is : Tue Dec 16 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Steve, Date of Birth is : Thu Dec 18 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 40 , Name of the children is : Nishu, Date of Birth is : Fri Dec 19 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 41 , Name of the children is : Mary, Date of Birth is : Mon Nov 17 00:00:00 IST 2014, Group assigned is : Group 4
Age is : 48 , Name of the children is : Bobby, Date of Birth is : Thu Apr 17 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Linda, Date of Birth is : Thu Apr 17 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Pinky, Date of Birth is : Thu Apr 17 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Lemon, Date of Birth is : Thu Apr 17 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Tesla, Date of Birth is : Wed Apr 16 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Guru, Date of Birth is : Thu Apr 10 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Niti, Date of Birth is : Fri Apr 11 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Cindy, Date of Birth is : Sat Apr 12 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Kuli, Date of Birth is : Sun Apr 13 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Medan, Date of Birth is : Mon Apr 14 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 48 , Name of the children is : Posy, Date of Birth is : Tue Apr 15 00:00:00 IST 2014, Group assigned is : Group 5
Age is : 53 , Name of the children is : Stanley, Date of Birth is : Sun Nov 17 00:00:00 IST 2013, Group assigned is : Group 5
Age is : 62 , Name of the children is : Lizzy, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Mike, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Post, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Malone, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Pill, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Nill, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Vox, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Cox, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Deck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Peck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Meck, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Like, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Mole, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 62 , Name of the children is : Nike, Date of Birth is : Sun Feb 17 00:00:00 IST 2013, Group assigned is : Group 6
Age is : 63 , Name of the children is : Millie, Date of Birth is : Thu Jan 17 00:00:00 IST 2013, Group assigned is : Group 6
********** Sorted List Of Childrens on Age Ends***********
################ Welcome to NEU Daycare ################ 

*****************Vaccination Alarm******************* 

Student Having  Name : Jimmy, Date of Registration : 2017-03-31
Sorry, your Vaccination Date was: 2017-09-30, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Sally, Date of Registration : 2018-07-20
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-10-20
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2019-01-20


Student Having  Name : Lizzy, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Markie, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Johnny, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Bobby, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Billy, Date of Registration : 2018-07-20
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-10-20
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2019-01-20


Student Having  Name : Evie, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Becky, Date of Registration : 2017-03-31
Sorry, your Vaccination Date was: 2017-09-30, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Jessie, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Jackie, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Laurie, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Cathey, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Millie, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Ruthie, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Stanley, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Mary, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Annie, Date of Registration : 2017-03-31
Sorry, your Vaccination Date was: 2017-09-30, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Melisa, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Mia, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Lorren, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Michael, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Tony, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Lia, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Jay, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Steve, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Nishu, Date of Registration : 2017-03-31
Sorry, your Vaccination Date was: 2017-09-30, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Linda, Date of Registration : 2018-07-20
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-10-20
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2019-01-20


Student Having  Name : Pinky, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Lemon, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Tesla, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Guru, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Niti, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Cindy, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Kuli, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Medan, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Posy, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Mike, Date of Registration : 2017-03-31
Sorry, your Vaccination Date was: 2017-09-30, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Post, Date of Registration : 2018-07-20
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-10-20
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2019-01-20


Student Having  Name : Malone, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Pill, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Nill, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Vox, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Cox, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Deck, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Peck, Date of Registration : 2018-01-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b)


Student Having  Name : Medan, Date of Registration : 2018-02-26
Comeback Later for vaccination
3 Vaccinations : Pneumococcal (PCV), Polio (IPV) & Hib (Haemophilus influenzae type b) due after 3 months on 2018-05-26
2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV) due after 6 months on 2018-08-26


Student Having  Name : Meck, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Like, Date of Registration : 2017-10-20
Sorry, your Vaccination Date was: 2018-04-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)


Student Having  Name : Nike, Date of Registration : 2017-07-20
Sorry, your Vaccination Date was: 2018-01-20, it has passed, Please take 2 Vaccinations : Hepatitis B (Hep B) & Rotavirus (RV)




*****************Registration Alarm******************* 

Student Having  Name : Jimmy, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Sally, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Lizzy, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Markie, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Johnny, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Bobby, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Billy, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Evie, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Becky, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Jessie, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Jackie, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Cathey, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Cathey, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Millie, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Ruthie, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Stanley, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Mary, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Annie, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Melisa, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Mia, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Lorren, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Michael, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Tony, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Lia, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Jay, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Steve, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Nishu, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Linda, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Pinky, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Lemon, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Tesla, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Guru, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Niti, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Cindy, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Kuli, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Medan, Date of Registration : 2017-01-13
Sorry, your Registration Date was: 2018-01-13, it has passed, Please renew your Registration.


Student Having  Name : Posy, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Mike, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Post, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Malone, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Pill, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Nill, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Vox, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Cox, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Deck, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.


Student Having  Name : Peck, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Medan, Date of Registration : 2017-02-26
Sorry, your Registration Date was: 2018-02-26, it has passed, Please renew your Registration.


Student Having  Name : Meck, Date of Registration : 2017-07-02
Comeback Later for Registration
Registration due on 2018-07-02 Please renew your registration once it is expired.


Student Having  Name : Like, Date of Registration : 2017-04-20
Sorry, your Registration Date was: 2018-04-20, it has passed, Please renew your Registration.


Student Having  Name : Nike, Date of Registration : 2017-08-31
Comeback Later for Registration
Registration due on 2018-08-31 Please renew your registration once it is expired.
                
                */
	}
}
