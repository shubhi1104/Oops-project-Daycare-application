package edu.neu.csye6200;

public class Person extends AbstractPersonAPI{

	@Override
	public void show() {
		// TODO Auto-generated method stub
	}

}
