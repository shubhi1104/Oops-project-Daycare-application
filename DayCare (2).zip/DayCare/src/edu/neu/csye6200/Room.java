package edu.neu.csye6200;

public class Room {
	
	private String roomNumber;

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}
	
	public void show() {
		System.out.println(this.toString());
		System.out.println("\n");
	}

	@Override
	public String toString() {
		return "Room number is : " + roomNumber;
	}

}
