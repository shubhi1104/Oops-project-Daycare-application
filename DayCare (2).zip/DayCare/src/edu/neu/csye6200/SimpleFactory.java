package edu.neu.csye6200;

import java.text.ParseException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SimpleFactory {


	enum SimpleCriteria {
		CHILDREN, TEACHER, REGISTRATION, VACCINE
	}

	private SimpleFactory() {

	}
	
	static List<Children> childrenList = new ArrayList<Children>();

	public static Person getObject(SimpleCriteria criteria) throws ParseException {
		Person obj = null;
		if (criteria == SimpleCriteria.CHILDREN) {
			obj = new Children();
		} else if (criteria == SimpleCriteria.TEACHER) {
			obj = new Teacher();
		}
		return obj;
	}

	public static Person getObject(SimpleCriteria criteria, String name, Date date) {
		Person obj = null;
		if (criteria == SimpleCriteria.CHILDREN) {
			obj = new Children(name, date, childrenList);
		} else if (criteria == SimpleCriteria.TEACHER) {
			//obj = new Bread(id, name, price, cost);
		}
		return obj;
	}
	
	public static Alarm_Clock getbjectAlarmClock(SimpleCriteria criteria,LocalDate date,String name) {
		
		Alarm_Clock obj = null;
		if(criteria == SimpleCriteria.REGISTRATION) {
			obj = new Registration(date, name);
		} else if(criteria == SimpleCriteria.VACCINE) {
			obj = new Vaccine(date, name);
		}
		return obj;
		
	}
}
