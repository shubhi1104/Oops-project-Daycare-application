package edu.neu.csye6200;

import java.util.ArrayList;
import java.util.List;

public class Teacher extends Person {
	
	private String teacherName;
	private String groupName;
	private List<Children> teacherList = new ArrayList<Children>();
	private List<Children> teacherList2 = new ArrayList<Children>();
	
	
	/*public Teacher(String teacherName, String groupName) {
		this.teacherName = teacherName;
		this.groupName = groupName;
		this.childrenList = new ArrayList<Children>();
	}*/
	
	
	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	@Override
	public String toString() {
		return "Teacher Name is : " + this.teacherName;
	}

	@Override
	public void show() {
		System.out.println(this.toString());
	}

	public List<Children> getTeacherList() {
		return teacherList;
	}

	public void setTeacherList(List<Children> teacherList) {
		this.teacherList = teacherList;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public void addChildren(Children children) {
		// TODO Auto-generated method stub
		
		
			System.out.println("-----" + children.getGroup());
			if(children.getGroup().equalsIgnoreCase("Group 1")){
				teacherList.add(children);
				if(teacherList.size() > 4) {
					System.out.println("Cannot assign more than 4 Childrens of Group 1 to Teacher 1");
				}
				//System.out.println("In Teacher class " + teacherList);
			}else if(children.getGroup().equalsIgnoreCase("Group 2")) {
				teacherList2.add(children);
				//System.out.println("In Teacher class " + teacherList2);
			}
		
		
		
	}

}
